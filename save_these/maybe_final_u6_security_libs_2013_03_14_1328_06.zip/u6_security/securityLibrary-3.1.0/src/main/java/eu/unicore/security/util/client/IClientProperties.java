/*
 * Copyright (c) 2012 ICM Uniwersytet Warszawski All rights reserved.
 * See LICENCE.txt file for licensing information.
 */
package eu.unicore.security.util.client;

import eu.unicore.util.httpclient.IClientConfiguration;

/**
 * @deprecated Use {@link IClientConfiguration} instead
 * @author K. Benedyczak
 */
@Deprecated
public interface IClientProperties extends IClientConfiguration
{

}
